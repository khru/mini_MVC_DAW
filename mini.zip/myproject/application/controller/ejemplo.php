<?php

class Ejemplo extends Controller
{
    public function index(){
        echo "Estoy en el método Index del controlador Ejemplo";
    }

    public function acercade(){
        echo "Somos el curso de 2º DAW";
    }
}