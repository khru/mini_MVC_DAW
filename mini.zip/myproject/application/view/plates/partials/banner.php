<div class="container">
    Este texto imita un banner
    <p><?= $titulo ?></p>
    <p><?= $dato ?></p>
</div>