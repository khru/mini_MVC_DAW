<?php $this->layout('layout-error') ?>
<div class="container">
    <p>Estamos en "Plates"</p>
    <p>This is the Error-page. Will be shown when a page (= controller / method) does not exist.</p>
    <p><?= $msg ?></p>
</div>