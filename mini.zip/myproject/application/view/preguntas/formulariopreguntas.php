<div class="conteiner">
	<h2>¿Qué quieres preguntar?</h2>
	<p>Dinos cuál es tú pregunta. Al preguntar trata de ser claro y conciso.</p>
	<form action="<?= $_SERVER["REQUEST_URI"] ; ?>" name="preguntas" method="POST">
		<p>
			<label for="asunto">Asunto:</label>
			<span>
				<input type="text" name="" placeholder="" >
			</span>
		</p>
		<p>
			<label for="cuerpo">Cuerpo:</label>
			<!-- Campo textarea -->
			<textarea name="" id="" cols="30" rows="10">

			</textarea>
		</p>
		<p>
			<!-- Boton submit -->
			<input class="enviar" type="submit" name="" value="Enviar">
		</p>
	</form>
</div>