<div class="container">
    Hola Mundo!!!
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum laudantium iste alias tenetur ullam consequuntur dolore esse, natus. Totam architecto ipsam dicta quia, at laboriosam quas maxime quae. Nihil, iusto.</p>
    <?= APP ?>
</div>