<?php
class Preguntas extends Controller
{
    public function todas(){
        $preguntas = PreguntasModel::getAll();
        $this->view->render('preguntas/todas',
            array('preguntas' => $preguntas));
    }

}