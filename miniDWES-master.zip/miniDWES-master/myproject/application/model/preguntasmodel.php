<?php
class PreguntasModel
{
    //Recibimos todas las preguntas
    public static function getAll(){
        $conn = Database::getInstance()->getDatabase();
        $ssql = "SELECT * FROM pregunta";
        $query = $conn->prepare($ssql);
        $query->execute();
        return $query->fetchAll();
    }
}